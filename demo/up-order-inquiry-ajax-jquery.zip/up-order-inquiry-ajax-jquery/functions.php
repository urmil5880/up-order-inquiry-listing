<?php
/**
 * Twenty Seventeen functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 */

/**
 * Twenty Seventeen only works in WordPress 4.7 or later.
 */
if ( version_compare( $GLOBALS['wp_version'], '4.7-alpha', '<' ) ) {
	require get_template_directory() . '/inc/back-compat.php';
	return;
}

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function twentyseventeen_setup() {
	/*
	 * Make theme available for translation.
	 * Translations can be filed at WordPress.org. See: https://translate.wordpress.org/projects/wp-themes/twentyseventeen
	 * If you're building a theme based on Twenty Seventeen, use a find and replace
	 * to change 'twentyseventeen' to the name of your theme in all the template files.
	 */
	load_theme_textdomain( 'twentyseventeen' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support( 'post-thumbnails' );

	add_image_size( 'twentyseventeen-featured-image', 2000, 1200, true );

	add_image_size( 'twentyseventeen-thumbnail-avatar', 100, 100, true );

	// Set the default content width.
	$GLOBALS['content_width'] = 525;

	// This theme uses wp_nav_menu() in two locations.
	register_nav_menus( array(
		'top'    => __( 'Top Menu', 'twentyseventeen' ),
		'social' => __( 'Social Links Menu', 'twentyseventeen' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );

	/*
	 * Enable support for Post Formats.
	 *
	 * See: https://codex.wordpress.org/Post_Formats
	 */
	add_theme_support( 'post-formats', array(
		'aside',
		'image',
		'video',
		'quote',
		'link',
		'gallery',
		'audio',
	) );

	// Add theme support for Custom Logo.
	add_theme_support( 'custom-logo', array(
		'width'       => 250,
		'height'      => 250,
		'flex-width'  => true,
	) );

	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );

	/*
	 * This theme styles the visual editor to resemble the theme style,
	 * specifically font, colors, and column width.
 	 */
	add_editor_style( array( 'assets/css/editor-style.css', twentyseventeen_fonts_url() ) );

	// Define and register starter content to showcase the theme on new sites.
	$starter_content = array(
		'widgets' => array(
			// Place three core-defined widgets in the sidebar area.
			'sidebar-1' => array(
				'text_business_info',
				'search',
				'text_about',
			),

			// Add the core-defined business info widget to the footer 1 area.
			'sidebar-2' => array(
				'text_business_info',
			),

			// Put two core-defined widgets in the footer 2 area.
			'sidebar-3' => array(
				'text_about',
				'search',
			),
		),

		// Specify the core-defined pages to create and add custom thumbnails to some of them.
		'posts' => array(
			'home',
			'about' => array(
				'thumbnail' => '{{image-sandwich}}',
			),
			'contact' => array(
				'thumbnail' => '{{image-espresso}}',
			),
			'blog' => array(
				'thumbnail' => '{{image-coffee}}',
			),
			'homepage-section' => array(
				'thumbnail' => '{{image-espresso}}',
			),
		),

		// Create the custom image attachments used as post thumbnails for pages.
		'attachments' => array(
			'image-espresso' => array(
				'post_title' => _x( 'Espresso', 'Theme starter content', 'twentyseventeen' ),
				'file' => 'assets/images/espresso.jpg', // URL relative to the template directory.
			),
			'image-sandwich' => array(
				'post_title' => _x( 'Sandwich', 'Theme starter content', 'twentyseventeen' ),
				'file' => 'assets/images/sandwich.jpg',
			),
			'image-coffee' => array(
				'post_title' => _x( 'Coffee', 'Theme starter content', 'twentyseventeen' ),
				'file' => 'assets/images/coffee.jpg',
			),
		),

		// Default to a static front page and assign the front and posts pages.
		'options' => array(
			'show_on_front' => 'page',
			'page_on_front' => '{{home}}',
			'page_for_posts' => '{{blog}}',
		),

		// Set the front page section theme mods to the IDs of the core-registered pages.
		'theme_mods' => array(
			'panel_1' => '{{homepage-section}}',
			'panel_2' => '{{about}}',
			'panel_3' => '{{blog}}',
			'panel_4' => '{{contact}}',
		),

		// Set up nav menus for each of the two areas registered in the theme.
		'nav_menus' => array(
			// Assign a menu to the "top" location.
			'top' => array(
				'name' => __( 'Top Menu', 'twentyseventeen' ),
				'items' => array(
					'link_home', // Note that the core "home" page is actually a link in case a static front page is not used.
					'page_about',
					'page_blog',
					'page_contact',
				),
			),

			// Assign a menu to the "social" location.
			'social' => array(
				'name' => __( 'Social Links Menu', 'twentyseventeen' ),
				'items' => array(
					'link_yelp',
					'link_facebook',
					'link_twitter',
					'link_instagram',
					'link_email',
				),
			),
		),
	);

	/**
	 * Filters Twenty Seventeen array of starter content.
	 *
	 * @since Twenty Seventeen 1.1
	 *
	 * @param array $starter_content Array of starter content.
	 */
	$starter_content = apply_filters( 'twentyseventeen_starter_content', $starter_content );

	add_theme_support( 'starter-content', $starter_content );
}
add_action( 'after_setup_theme', 'twentyseventeen_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function twentyseventeen_content_width() {

	$content_width = $GLOBALS['content_width'];

	// Get layout.
	$page_layout = get_theme_mod( 'page_layout' );

	// Check if layout is one column.
	if ( 'one-column' === $page_layout ) {
		if ( twentyseventeen_is_frontpage() ) {
			$content_width = 644;
		} elseif ( is_page() ) {
			$content_width = 740;
		}
	}

	// Check if is single post and there is no sidebar.
	if ( is_single() && ! is_active_sidebar( 'sidebar-1' ) ) {
		$content_width = 740;
	}

	/**
	 * Filter Twenty Seventeen content width of the theme.
	 *
	 * @since Twenty Seventeen 1.0
	 *
	 * @param int $content_width Content width in pixels.
	 */
	$GLOBALS['content_width'] = apply_filters( 'twentyseventeen_content_width', $content_width );
}
add_action( 'template_redirect', 'twentyseventeen_content_width', 0 );

/**
 * Register custom fonts.
 */
function twentyseventeen_fonts_url() {
	$fonts_url = '';

	/*
	 * Translators: If there are charaordersrs in your language that are not
	 * supported by Libre Franklin, translate this to 'off'. Do not translate
	 * into your own language.
	 */
	$libre_franklin = _x( 'on', 'Libre Franklin font: on or off', 'twentyseventeen' );

	if ( 'off' !== $libre_franklin ) {
		$font_families = array();

		$font_families[] = 'Libre Franklin:300,300i,400,400i,600,600i,800,800i';

		$query_args = array(
			'family' => urlencode( implode( '|', $font_families ) ),
			'subset' => urlencode( 'latin,latin-ext' ),
		);

		$fonts_url = add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );
	}

	return esc_url_raw( $fonts_url );
}

/**
 * Add preconnect for Google Fonts.
 *
 * @since Twenty Seventeen 1.0
 *
 * @param array  $urls           URLs to print for resource hints.
 * @param string $relation_type  The relation type the URLs are printed.
 * @return array $urls           URLs to print for resource hints.
 */
function twentyseventeen_resource_hints( $urls, $relation_type ) {
	if ( wp_style_is( 'twentyseventeen-fonts', 'queue' ) && 'preconnect' === $relation_type ) {
		$urls[] = array(
			'href' => 'https://fonts.gstatic.com',
			'crossorigin',
		);
	}

	return $urls;
}
add_filter( 'wp_resource_hints', 'twentyseventeen_resource_hints', 10, 2 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function twentyseventeen_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Blog Sidebar', 'twentyseventeen' ),
		'id'            => 'sidebar-1',
		'description'   => __( 'Add widgets here to appear in your sidebar on blog posts and archive pages.', 'twentyseventeen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );

	register_sidebar( array(
		'name'          => __( 'Footer 1', 'twentyseventeen' ),
		'id'            => 'sidebar-2',
		'description'   => __( 'Add widgets here to appear in your footer.', 'twentyseventeen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );

	register_sidebar( array(
		'name'          => __( 'Footer 2', 'twentyseventeen' ),
		'id'            => 'sidebar-3',
		'description'   => __( 'Add widgets here to appear in your footer.', 'twentyseventeen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<p class="font-md text-black bold border-red">',
		'after_title'   => '</p>',
	) );
	
	register_sidebar( array(
		'name'          => __( 'Footer 3', 'twentyseventeen' ),
		'id'            => 'sidebar-4',
		'description'   => __( 'Add widgets here to appear in your footer.', 'twentyseventeen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<p class="font-md text-black bold border-red">',
		'after_title'   => '</p>',
	) );
	
	register_sidebar( array(
		'name'          => __( 'Footer 4', 'twentyseventeen' ),
		'id'            => 'sidebar-5',
		'description'   => __( 'Add widgets here to appear in your footer.', 'twentyseventeen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
	
	register_sidebar( array(
		'name'          => __( 'Top header left', 'twentyseventeen' ),
		'id'            => 'top-header-left',
		'description'   => __( 'Add widgets here to appear in your header.', 'twentyseventeen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
	
	register_sidebar( array(
		'name'          => __( 'Top header right', 'twentyseventeen' ),
		'id'            => 'top-header-right',
		'description'   => __( 'Add widgets here to appear in your header.', 'twentyseventeen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
	register_sidebar( array(
		'name'          => __( 'Contactus address', 'twentyseventeen' ),
		'id'            => 'contactus-address',
		'description'   => __( 'Add widgets here to appear in your header.', 'twentyseventeen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );

}
add_action( 'widgets_init', 'twentyseventeen_widgets_init' );

/**
 * Replaces "[...]" (appended to automatically generated excerpts) with ... and
 * a 'Continue reading' link.
 *
 * @since Twenty Seventeen 1.0
 *
 * @param string $link Link to single post/page.
 * @return string 'Continue reading' link prepended with an ellipsis.
 */
function twentyseventeen_excerpt_more( $link ) {
	if ( is_admin() ) {
		return $link;
	}

	$link = sprintf( '<p class="link-more"><a href="%1$s" class="more-link">%2$s</a></p>',
		esc_url( get_permalink( get_the_ID() ) ),
		/* translators: %s: Name of current post */
		sprintf( __( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'twentyseventeen' ), get_the_title( get_the_ID() ) )
	);
	return ' &hellip; ' . $link;
}
add_filter( 'excerpt_more', 'twentyseventeen_excerpt_more' );

/**
 * Handles JavaScript detection.
 *
 * Adds a `js` class to the root `<html>` element when JavaScript is deteordersd.
 *
 * @since Twenty Seventeen 1.0
 */
function twentyseventeen_javascript_detection() {
	echo "<script>(function(html){html.className = html.className.replace(/\bno-js\b/,'js')})(document.documentElement);</script>\n";
}
add_action( 'wp_head', 'twentyseventeen_javascript_detection', 0 );

/**
 * Add a pingback url auto-discovery header for singularly identifiable articles.
 */
function twentyseventeen_pingback_header() {
	if ( is_singular() && pings_open() ) {
		printf( '<link rel="pingback" href="%s">' . "\n", get_bloginfo( 'pingback_url' ) );
	}
}
add_action( 'wp_head', 'twentyseventeen_pingback_header' );

/**
 * Display custom color CSS.
 */
function twentyseventeen_colors_css_wrap() {
	if ( 'custom' !== get_theme_mod( 'colorscheme' ) && ! is_customize_preview() ) {
		return;
	}

	require_once( get_parent_theme_file_path( '/inc/color-patterns.php' ) );
	$hue = absint( get_theme_mod( 'colorscheme_hue', 250 ) );
?>
	<style type="text/css" id="custom-theme-colors" <?php if ( is_customize_preview() ) { echo 'data-hue="' . $hue . '"'; } ?>>
		<?php echo twentyseventeen_custom_colors_css(); ?>
	</style>
<?php }
add_action( 'wp_head', 'twentyseventeen_colors_css_wrap' );

/**
 * Enqueue scripts and styles.
 */
function twentyseventeen_scripts() {
	// Add custom fonts, used in the main stylesheet.
	wp_enqueue_style( 'twentyseventeen-fonts', twentyseventeen_fonts_url(), array(), null );
	
	// css file
	wp_enqueue_style( 'bootstrap.min.css', get_theme_file_uri( '/assets/css/bootstrap.min.css' ) );
	wp_enqueue_style( 'font-awesome.min.css', get_theme_file_uri( '/assets/css/font-awesome.min.css' ) );
	wp_enqueue_style( 'cutom.css', get_theme_file_uri( '/assets/css/custom.css' ));
	wp_enqueue_style( 'slick.min.css', get_theme_file_uri( '/assets/css/slick.min.css' ));
	wp_enqueue_style( 'responsive.css', get_theme_file_uri( '/assets/css/responsive.css' )); 

	// Theme stylesheet.
	wp_enqueue_style( 'twentyseventeen-style', get_stylesheet_uri() );

	// Load the dark colorscheme.
	if ( 'dark' === get_theme_mod( 'colorscheme', 'light' ) || is_customize_preview() ) {
		wp_enqueue_style( 'twentyseventeen-colors-dark', get_theme_file_uri( '/assets/css/colors-dark.css' ), array( 'twentyseventeen-style' ), '1.0' );
	}

	// Load the Internet Explorer 9 specific stylesheet, to fix display issues in the Customizer.
	if ( is_customize_preview() ) {
		wp_enqueue_style( 'twentyseventeen-ie9', get_theme_file_uri( '/assets/css/ie9.css' ), array( 'twentyseventeen-style' ), '1.0' );
		wp_style_add_data( 'twentyseventeen-ie9', 'conditional', 'IE 9' );
	}

	// Load the Internet Explorer 8 specific stylesheet.
	wp_enqueue_style( 'twentyseventeen-ie8', get_theme_file_uri( '/assets/css/ie8.css' ), array( 'twentyseventeen-style' ), '1.0' );
	wp_style_add_data( 'twentyseventeen-ie8', 'conditional', 'lt IE 9' );

	// Load the html5 shiv.
	wp_enqueue_script( 'html5', get_theme_file_uri( '/assets/js/html5.js' ), array(), '3.7.3' );
	wp_script_add_data( 'html5', 'conditional', 'lt IE 9' );

	wp_enqueue_script( 'twentyseventeen-skip-link-focus-fix', get_theme_file_uri( '/assets/js/skip-link-focus-fix.js' ), array(), '1.0', true );

	$twentyseventeen_l10n = array(
		'quote'          => twentyseventeen_get_svg( array( 'icon' => 'quote-right' ) ),
	);

	if ( has_nav_menu( 'top' ) ) {
		wp_enqueue_script( 'twentyseventeen-navigation', get_theme_file_uri( '/assets/js/navigation.js' ), array( 'jquery' ), '1.0', true );
		$twentyseventeen_l10n['expand']         = __( 'Expand child menu', 'twentyseventeen' );
		$twentyseventeen_l10n['collapse']       = __( 'Collapse child menu', 'twentyseventeen' );
		$twentyseventeen_l10n['icon']           = twentyseventeen_get_svg( array( 'icon' => 'angle-down', 'fallback' => true ) );
	}

	wp_enqueue_script( 'twentyseventeen-global', get_theme_file_uri( '/assets/js/global.js' ), array( 'jquery' ), '1.0', true );

	wp_enqueue_script( 'jquery-scrollto', get_theme_file_uri( '/assets/js/jquery.scrollTo.js' ), array( 'jquery' ), '2.1.2', true );
	
	
	// js file
	wp_enqueue_script( 'frontend-ajax', get_stylesheet_directory_uri() . '/assets/js/frontend-ajax.js', array('jquery'));
	wp_localize_script( 'frontend-ajax', 'frontendajax', array('ajaxurl' => admin_url('admin-ajax.php'),));


	wp_enqueue_script( 'jquery.min.js', get_theme_file_uri( '/assets/js/jquery.min.js' ), array());
	wp_enqueue_script( 'popper.min.js', get_theme_file_uri( '/assets/js/popper.min.js' ), array());
	wp_enqueue_script( 'bootstrap.min.js', get_theme_file_uri( '/assets/js/bootstrap.min.js' ), array() );
	wp_enqueue_script( 'custom.js', get_theme_file_uri( '/assets/js/custom.js' ), array() );
	wp_enqueue_script( 'slick.min.js', get_theme_file_uri( '/assets/js/slick.min.js' ), array() );

	wp_localize_script( 'twentyseventeen-skip-link-focus-fix', 'twentyseventeenScreenReaderText', $twentyseventeen_l10n );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'twentyseventeen_scripts' );

/**
 * Add custom image sizes attribute to enhance responsive image functionality
 * for content images.
 *
 * @since Twenty Seventeen 1.0
 *
 * @param string $sizes A source size value for use in a 'sizes' attribute.
 * @param array  $size  Image size. Accepts an array of width and height
 *                      values in pixels (in that order).
 * @return string A source size value for use in a content image 'sizes' attribute.
 */
function twentyseventeen_content_image_sizes_attr( $sizes, $size ) {
	$width = $size[0];

	if ( 740 <= $width ) {
		$sizes = '(max-width: 706px) 89vw, (max-width: 767px) 82vw, 740px';
	}

	if ( is_active_sidebar( 'sidebar-1' ) || is_archive() || is_search() || is_home() || is_page() ) {
		if ( ! ( is_page() && 'one-column' === get_theme_mod( 'page_options' ) ) && 767 <= $width ) {
			 $sizes = '(max-width: 767px) 89vw, (max-width: 1000px) 54vw, (max-width: 1071px) 543px, 580px';
		}
	}

	return $sizes;
}
add_filter( 'wp_calculate_image_sizes', 'twentyseventeen_content_image_sizes_attr', 10, 2 );

/**
 * Filter the `sizes` value in the header image markup.
 *
 * @since Twenty Seventeen 1.0
 *
 * @param string $html   The HTML image tag markup being filtered.
 * @param object $header The custom header object returned by 'get_custom_header()'.
 * @param array  $attr   Array of the attributes for the image tag.
 * @return string The filtered header image HTML.
 */
function twentyseventeen_header_image_tag( $html, $header, $attr ) {
	if ( isset( $attr['sizes'] ) ) {
		$html = str_replace( $attr['sizes'], '100vw', $html );
	}
	return $html;
}
add_filter( 'get_header_image_tag', 'twentyseventeen_header_image_tag', 10, 3 );

/**
 * Add custom image sizes attribute to enhance responsive image functionality
 * for post thumbnails.
 *
 * @since Twenty Seventeen 1.0
 *
 * @param array $attr       Attributes for the image markup.
 * @param int   $attachment Image attachment ID.
 * @param array $size       Registered image size or flat array of height and width dimensions.
 * @return array The filtered attributes for the image markup.
 */
function twentyseventeen_post_thumbnail_sizes_attr( $attr, $attachment, $size ) {
	if ( is_archive() || is_search() || is_home() ) {
		$attr['sizes'] = '(max-width: 767px) 89vw, (max-width: 1000px) 54vw, (max-width: 1071px) 543px, 580px';
	} else {
		$attr['sizes'] = '100vw';
	}

	return $attr;
}
add_filter( 'wp_get_attachment_image_attributes', 'twentyseventeen_post_thumbnail_sizes_attr', 10, 3 );

/**
 * Use front-page.php when Front page displays is set to a static page.
 *
 * @since Twenty Seventeen 1.0
 *
 * @param string $template front-page.php.
 *
 * @return string The template to be used: blank if is_home() is true (defaults to index.php), else $template.
 */
function twentyseventeen_front_page_template( $template ) {
	return is_home() ? '' : $template;
}
add_filter( 'frontpage_template',  'twentyseventeen_front_page_template' );

/**
 * Modifies tag cloud widget arguments to display all tags in the same font size
 * and use list format for better accessibility.
 *
 * @since Twenty Seventeen 1.4
 *
 * @param array $args Arguments for tag cloud widget.
 * @return array The filtered arguments for tag cloud widget.
 */
function twentyseventeen_widget_tag_cloud_args( $args ) {
	$args['largest']  = 1;
	$args['smallest'] = 1;
	$args['unit']     = 'em';
	$args['format']   = 'list';

	return $args;
}
add_filter( 'widget_tag_cloud_args', 'twentyseventeen_widget_tag_cloud_args' );

/**
 * Implement the Custom Header feature.
 */
require get_parent_theme_file_path( '/inc/custom-header.php' );

/**
 * Custom template tags for this theme.
 */
require get_parent_theme_file_path( '/inc/template-tags.php' );

/**
 * Additional features to allow styling of the templates.
 */
require get_parent_theme_file_path( '/inc/template-functions.php' );

/**
 * Customizer additions.
 */
require get_parent_theme_file_path( '/inc/customizer.php' );

/**
 * SVG icons functions and filters.
 */
require get_parent_theme_file_path( '/inc/icon-functions.php' );
/*****************************/
// Register Custom Post Type
function client_feedback_custom_post_type() {

	$labels = array(
		'name'                  => _x( 'Client Feedback', 'Post Type General Name', 'clientfeedback_domain' ),
		'singular_name'         => _x( 'Client Feedback Type', 'Post Type Singular Name', 'clientfeedback_domain' ),
		'menu_name'             => __( 'Client Feedback', 'clientfeedback_domain' ),
		'name_admin_bar'        => __( 'Client Feedback Type', 'clientfeedback_domain' ),
		'archives'              => __( 'Item Archives', 'clientfeedback_domain' ),
		'attributes'            => __( 'Item Attributes', 'clientfeedback_domain' ),
		'parent_item_colon'     => __( 'Parent Item:', 'clientfeedback_domain' ),
		'all_items'             => __( 'All Items', 'clientfeedback_domain' ),
		'add_new_item'          => __( 'Add New Item', 'clientfeedback_domain' ),
		'add_new'               => __( 'Add New', 'clientfeedback_domain' ),
		'new_item'              => __( 'New Item', 'clientfeedback_domain' ),
		'edit_item'             => __( 'Edit Item', 'clientfeedback_domain' ),
		'update_item'           => __( 'Update Item', 'clientfeedback_domain' ),
		'view_item'             => __( 'View Item', 'clientfeedback_domain' ),
		'view_items'            => __( 'View Items', 'clientfeedback_domain' ),
		'search_items'          => __( 'Search Item', 'clientfeedback_domain' ),
		'not_found'             => __( 'Not found', 'clientfeedback_domain' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'clientfeedback_domain' ),
		'featured_image'        => __( 'Client Image', 'clientfeedback_domain' ),
		'set_featured_image'    => __( 'Set client image', 'clientfeedback_domain' ),
		'remove_featured_image' => __( 'Remove client image', 'clientfeedback_domain' ),
		'use_featured_image'    => __( 'Use as client image', 'clientfeedback_domain' ),
		'insert_into_item'      => __( 'Insert into item', 'clientfeedback_domain' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'clientfeedback_domain' ),
		'items_list'            => __( 'Items list', 'clientfeedback_domain' ),
		'items_list_navigation' => __( 'Items list navigation', 'clientfeedback_domain' ),
		'filter_items_list'     => __( 'Filter items list', 'clientfeedback_domain' ),
	);
	$args = array(
		'label'                 => __( 'Client Feedback Type', 'clientfeedback_domain' ),
		'description'           => __( 'Client Feedback Type Description', 'clientfeedback_domain' ),
		'labels'                => $labels,
		'supports'              => array('title', 'editor','thumbnail'),
		'taxonomies'            => array( ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'             => 'dashicons-format-quote',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'feedback', $args );

}
add_action( 'init', 'client_feedback_custom_post_type', 0 );
// Sustainability Register Custom Post Type
function sustainability_custom_post_type() {

	$labels = array(
		'name'                  => _x( 'Post Types', 'Post Type General Name', 'text_domain' ),
		'singular_name'         => _x( 'Post Type', 'Post Type Singular Name', 'text_domain' ),
		'menu_name'             => __( 'Sustainability', 'text_domain' ),
		'name_admin_bar'        => __( 'Post Type', 'text_domain' ),
		'archives'              => __( 'Item Archives', 'text_domain' ),
		'attributes'            => __( 'Item Attributes', 'text_domain' ),
		'parent_item_colon'     => __( 'Parent Item:', 'text_domain' ),
		'all_items'             => __( 'All Items', 'text_domain' ),
		'add_new_item'          => __( 'Add New Item', 'text_domain' ),
		'add_new'               => __( 'Add New', 'text_domain' ),
		'new_item'              => __( 'New Item', 'text_domain' ),
		'edit_item'             => __( 'Edit Item', 'text_domain' ),
		'update_item'           => __( 'Update Item', 'text_domain' ),
		'view_item'             => __( 'View Item', 'text_domain' ),
		'view_items'            => __( 'View Items', 'text_domain' ),
		'search_items'          => __( 'Search Item', 'text_domain' ),
		'not_found'             => __( 'Not found', 'text_domain' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'text_domain' ),
		'featured_image'        => __( 'Featured Image', 'text_domain' ),
		'set_featured_image'    => __( 'Set featured image', 'text_domain' ),
		'remove_featured_image' => __( 'Remove featured image', 'text_domain' ),
		'use_featured_image'    => __( 'Use as featured image', 'text_domain' ),
		'insert_into_item'      => __( 'Insert into item', 'text_domain' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'text_domain' ),
		'items_list'            => __( 'Items list', 'text_domain' ),
		'items_list_navigation' => __( 'Items list navigation', 'text_domain' ),
		'filter_items_list'     => __( 'Filter items list', 'text_domain' ),
	);
	$args = array(
		'label'                 => __( 'Post Type', 'text_domain' ),
		'description'           => __( 'Sustainability Description', 'text_domain' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'thumbnail' ),
		'taxonomies'            => array( ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
		'rewrite' => array('slug' => 'sustainabilit'),

		
	);
	register_post_type( 'sustainability', $args );

}
add_action( 'init', 'sustainability_custom_post_type', 0 );

//Products Register Custom Post Type
function products_custom_post_type() {

	$labels = array(
		'name'                  => _x( 'Products', 'Post Type General Name', 'product_domain' ),
		'singular_name'         => _x( 'Product', 'Post Type Singular Name', 'product_domain' ),
		'menu_name'             => __( 'Products', 'product_domain' ),
		'name_admin_bar'        => __( 'Post Type', 'product_domain' ),
		'archives'              => __( 'Item Archives', 'product_domain' ),
		'attributes'            => __( 'Item Attributes', 'product_domain' ),
		'parent_item_colon'     => __( 'Parent Item:', 'product_domain' ),
		'all_items'             => __( 'All Products', 'product_domain' ),
		'add_new_item'          => __( 'Add New Item', 'product_domain' ),
		'add_new'               => __( 'Add Product', 'product_domain' ),
		'new_item'              => __( 'New Item', 'product_domain' ),
		'edit_item'             => __( 'Edit Item', 'product_domain' ),
		'update_item'           => __( 'Update Item', 'product_domain' ),
		'view_item'             => __( 'View Item', 'product_domain' ),
		'view_items'            => __( 'View Items', 'product_domain' ),
		'search_items'          => __( 'Search Item', 'product_domain' ),
		'not_found'             => __( 'Not found', 'product_domain' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'product_domain' ),
		'featured_image'        => __( 'Product Image', 'product_domain' ),
		'set_featured_image'    => __( 'Set product image', 'product_domain' ),
		'remove_featured_image' => __( 'Remove product image', 'product_domain' ),
		'use_featured_image'    => __( 'Use as product image', 'product_domain' ),
		'insert_into_item'      => __( 'Insert into item', 'product_domain' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'product_domain' ),
		'items_list'            => __( 'Items list', 'product_domain' ),
		'items_list_navigation' => __( 'Items list navigation', 'product_domain' ),
		'filter_items_list'     => __( 'Filter items list', 'product_domain' ),
	);
	$args = array(
		'label'                 => __( 'Product', 'product_domain' ),
		'description'           => __( 'Product Description', 'product_domain' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'thumbnail'),
		'taxonomies'            => array( ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'             => 'dashicons-products',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',


	);
	register_post_type( 'products', $args );

}
add_action( 'init', 'products_custom_post_type', 0 );
// Products Categories Register Custom Taxonomy
function up_product_taxonomy() {

	$labels = array(
		'name'                       => _x( 'Products Categories', 'Taxonomy General Name', 'product_taxonomy' ),
		'singular_name'              => _x( 'Product Category', 'Taxonomy Singular Name', 'product_taxonomy' ),
		'menu_name'                  => __( 'Product Category', 'product_taxonomy' ),
		'all_items'                  => __( 'All Items', 'product_taxonomy' ),
		'parent_item'                => __( 'Parent Item', 'product_taxonomy' ),
		'parent_item_colon'          => __( 'Parent Item:', 'product_taxonomy' ),
		'new_item_name'              => __( 'New Item Name', 'product_taxonomy' ),
		'add_new_item'               => __( 'Add New Item', 'product_taxonomy' ),
		'edit_item'                  => __( 'Edit Item', 'product_taxonomy' ),
		'update_item'                => __( 'Update Item', 'product_taxonomy' ),
		'view_item'                  => __( 'View Item', 'product_taxonomy' ),
		'separate_items_with_commas' => __( 'Separate items with commas', 'product_taxonomy' ),
		'add_or_remove_items'        => __( 'Add or remove items', 'product_taxonomy' ),
		'choose_from_most_used'      => __( 'Choose from the most used', 'product_taxonomy' ),
		'popular_items'              => __( 'Popular Items', 'product_taxonomy' ),
		'search_items'               => __( 'Search Items', 'product_taxonomy' ),
		'not_found'                  => __( 'Not Found', 'product_taxonomy' ),
		'no_terms'                   => __( 'No items', 'product_taxonomy' ),
		'items_list'                 => __( 'Items list', 'product_taxonomy' ),
		'items_list_navigation'      => __( 'Items list navigation', 'product_taxonomy' ),
	);
	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => true,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,

		
        /*'rewrite'       		     => array( 'slug' => 'products_cat' )*/
	);
	//register_taxonomy( 'products_category', array( 'products' ), $args );

	register_taxonomy( 'products_category', array( 'products' ), array(
		'labels'                     => $labels,
		'hierarchical'               => true,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'exclude_from_search'        => false,
		'query_var'              	 => true,
		) );

}
add_action( 'init', 'up_product_taxonomy', 0 );
/****************************/
add_filter('wpcf7_form_elements', function($content) {
    $content = preg_replace('/<(span).*?class="\s*(?:.*\s)?wpcf7-form-control-wrap(?:\s[^"]+)?\s*"[^\>]*>(.*)<\/\1>/i', '\2', $content);

    return $content;
});

/**********/
   
add_action( 'wp_ajax_get_categorydata', 'get_categorydata' );
add_action( 'wp_ajax_nopriv_get_categorydata', 'get_categorydata' );
function get_categorydata() {

      global $post;

      $cat_id = $_POST['cat'];

      $args = array(
			'post_type' => 'products',
			'posts_per_page' => -1,
			'tax_query' => array(
				array(
					'hide_empty' => 0,
					'taxonomy' => 'products_category',
					'field'    => 'id',
					'terms'    => $cat_id,
				),
			),
		);
		
      $query = new WP_Query( $args );
      $count = count( $query );

      echo '<div class="product-listing mt-3 col px-lg-0"><div class="row">';
		if( $query->have_posts() ) :
		    while( $query->have_posts() ): $query->the_post();
		        
				$result = '<div class="col-md-3 d-flex product-box">';
					$result .= '<div class="col product-items px-0">';
							if (has_post_thumbnail( $post->ID ) ): 
								$proimage = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' );
								$result .='<a href=""  class="product-image"><img src="'.$proimage[0].'"/></a>';
							endif; 
						$diameter 		= get_field("diameter");
						$diameter_text 	= get_field("diameter_text");
						$capacity 		= get_field("capacity");
						$capacity_text 	= get_field("capacity_text");
						$color 			= get_field("color");
						$color_text 	= get_field("color_text");

						$result .= '<div class="product-disc">';
							$result .= '<a href="#" class="font-medium text-center product-title">'. get_the_title() .'</a>';
							                        
								$result .= '<ul class="product-disc-list">';
							   		if($diameter !=''){
							   			$result .= '<li>';
								   		$result .= '<p class="w-50 d-inline-block mb-0">'.$diameter_text.'<span class="float-right">:</span></p>';
								   		$result .= '<p class="d-inline-block pl-2 mb-0">'.$diameter.'</p>';
								        $result .= '</li>';	
							   		}
							   		
							   		if($capacity !=''){
								   		$result .= '<li>';
								    	$result .= '<p class="w-50 d-inline-block mb-0">'.$capacity_text.'<span class="float-right">:</span></p>';
								    	$result .= '<p class="d-inline-block pl-2 mb-0">'.$capacity.'</p>';
								    	$result .= '</li>';
								    }

								    if($color !=''){
								    	$result .= '<li>';
								    	$result .= '<p class="w-50 d-inline-block mb-0">'.$color_text.'<span class="float-right">:</span></p>';
								    	$result .= '<p class="d-inline-block pl-2 mb-0">'.$color.'<p>';
								    	$result .= '</li>';
								    }

							   $result .= '</ul>';
						 
				$result .='</div></div></div>';


				echo $result;	
		    endwhile;
		    wp_reset_postdata();
		else :
		    echo '<h4 class="text-center mt-4 col-12">No Product Found</h4>';
		endif;

		die(1); 
       echo '</div></div>'; 
   
} 


//Page Slug Body Class
function add_slug_body_class( $classes ) {
	global $post;
	if (isset( $post ) ) {
		
		if (wp_is_mobile()) {
			$classes[] = 'mobile_show';
		}else{
			$classes[] = 'desktop_show';
		}	
	}
	return $classes;
}
add_filter( 'body_class', 'add_slug_body_class' );
/*************************************
		SVG allow 
**************************************/
function cc_mime_types($mimes) {
  $mimes['svg'] = 'image/svg+xml';
  return $mimes;
}
add_filter('upload_mimes', 'cc_mime_types');
/*********************************
		SVG allow  End
********************************/
/***************
Search only products
******************/
add_filter( 'pre_get_posts','search_only_blog_posts' );

function search_only_blog_posts( $query ) {

    if ( $query->is_search ) {

        $query->set( 'post_type', 'products' );
    }
    return $query;
}
/***************
Search only products End
******************/
// Register Custom Post Type
function rx_order_custom_post_type() {

	$labels = array(
		'name'                  => _x( 'Order Forms', 'Post Type General Name', 'order_domain' ),
		'singular_name'         => _x( 'Order Form', 'Post Type Singular Name', 'order_domain' ),
		'menu_name'             => __( 'Order Forms', 'order_domain' ),
		'name_admin_bar'        => __( 'Order Form', 'order_domain' ),
		'archives'              => __( 'Item Archives', 'order_domain' ),
		'attributes'            => __( 'Item Attributes', 'order_domain' ),
		'parent_item_colon'     => __( 'Parent Item:', 'order_domain' ),
		'all_items'             => __( 'All Items', 'order_domain' ),
		'add_new_item'          => __( 'Add New Item', 'order_domain' ),
		'add_new'               => __( 'Add New', 'order_domain' ),
		'new_item'              => __( 'New Item', 'order_domain' ),
		'edit_item'             => __( 'Edit Item', 'order_domain' ),
		'update_item'           => __( 'Update Item', 'order_domain' ),
		'view_item'             => __( 'View Item', 'order_domain' ),
		'view_items'            => __( 'View Items', 'order_domain' ),
		'search_items'          => __( 'Search Item', 'order_domain' ),
		'not_found'             => __( 'Not found', 'order_domain' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'order_domain' ),
		'featured_image'        => __( 'Featured Image', 'order_domain' ),
		'set_featured_image'    => __( 'Set featured image', 'order_domain' ),
		'remove_featured_image' => __( 'Remove featured image', 'order_domain' ),
		'use_featured_image'    => __( 'Use as featured image', 'order_domain' ),
		'insert_into_item'      => __( 'Insert into item', 'order_domain' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'order_domain' ),
		'items_list'            => __( 'Items list', 'order_domain' ),
		'items_list_navigation' => __( 'Items list navigation', 'order_domain' ),
		'filter_items_list'     => __( 'Filter items list', 'order_domain' ),
	);
	$args = array(
		'label'                 => __( 'Order Form', 'order_domain' ),
		'description'           => __( 'Order Form Description', 'order_domain' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor' ),
		'taxonomies'            => array(),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'             => 'dashicons-carrot',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => true,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'order_form', $args );

}
add_action( 'init', 'rx_order_custom_post_type', 0 );

// Register Custom Taxonomy
function rx_order_custom_taxonomy() {

	$labels = array(
		'name'                       => _x( 'Order Taxonomies', 'Taxonomy General Name', 'order_taxo_domain' ),
		'singular_name'              => _x( 'Order Taxonomy', 'Taxonomy Singular Name', 'order_taxo_domain' ),
		'menu_name'                  => __( 'Order Category', 'order_taxo_domain' ),
		'all_items'                  => __( 'All Items', 'order_taxo_domain' ),
		'parent_item'                => __( 'Parent Item', 'order_taxo_domain' ),
		'parent_item_colon'          => __( 'Parent Item:', 'order_taxo_domain' ),
		'new_item_name'              => __( 'New Item Name', 'order_taxo_domain' ),
		'add_new_item'               => __( 'Add New Item', 'order_taxo_domain' ),
		'edit_item'                  => __( 'Edit Item', 'order_taxo_domain' ),
		'update_item'                => __( 'Update Item', 'order_taxo_domain' ),
		'view_item'                  => __( 'View Item', 'order_taxo_domain' ),
		'separate_items_with_commas' => __( 'Separate items with commas', 'order_taxo_domain' ),
		'add_or_remove_items'        => __( 'Add or remove items', 'order_taxo_domain' ),
		'choose_from_most_used'      => __( 'Choose from the most used', 'order_taxo_domain' ),
		'popular_items'              => __( 'Popular Items', 'order_taxo_domain' ),
		'search_items'               => __( 'Search Items', 'order_taxo_domain' ),
		'not_found'                  => __( 'Not Found', 'order_taxo_domain' ),
		'no_terms'                   => __( 'No items', 'order_taxo_domain' ),
		'items_list'                 => __( 'Items list', 'order_taxo_domain' ),
		'items_list_navigation'      => __( 'Items list navigation', 'order_taxo_domain' ),
	);
	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => true,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,
		'exclude_from_search'        => false,
		'query_var'              	 => true,
	);
	register_taxonomy( 'order_cat', array( 'order_form' ), $args );

}
add_action( 'init', 'rx_order_custom_taxonomy', 0 );


function rx_order_ajax_scripts() {

	wp_enqueue_script( 'frontend-ajax', get_stylesheet_directory_uri() . '/assets/js/frontend-ajax.js', array('jquery'));
	wp_localize_script( 'frontend-ajax', 'frontendajax', array('ajaxurl' => admin_url('admin-ajax.php'),));
}
//add_action( 'wp_enqueue_scripts', 'rx_order_ajax_scripts' );

// get cat parent + Product Name assign data
function rx_get_cat_parent(){
	
	 $parent_id = $_POST['parentId'];
	 $parent_slug = $_POST['parentSlug'];


        $get_parent_id = get_term_by('slug', $parent_slug, 'order_cat');
        $parent_id = $get_parent_id->term_id;

        $parentcat = get_terms( 'order_cat', 'hide_empty=0&parent='.$parent_id);
            foreach ($parentcat as $child) {
            	
            	$option .= '<option data-cat-child-slug="'.$child->slug.'" data-cat-child-id="'.$child->term_id.'" value="'.$child->name.'">';
                $option .= $child->name;
                $option .= '</option>';
            }
        echo '<option value="0" seleordersd="seleordersd">Select Product</option>'.$option;
        //echo $option;
        die();


}
add_action('wp_ajax_nopriv_rx_get_cat_parent', 'rx_get_cat_parent');
add_action('wp_ajax_rx_get_cat_parent', 'rx_get_cat_parent');

// get cat child + + Product Description assign data
function rx_get_cat_child(){

	$childcat_id = $_POST['childparentId'];
	$childparent_slug = $_POST['childparentSlug'];

	$get_parent_id = get_term_by('slug', $childparent_slug, 'order_cat');
        $childcat_id = $get_parent_id->term_id;

        $parentcat = get_terms( 'order_cat', 'hide_empty=0&child_of='.$childcat_id);
            foreach ($parentcat as $child) {
            	$option .= '<option data-cat-child-id="'.$child->term_id.'" value="'.$child->name.'">';
                $option .= $child->name;
                $option .= '</option>';
            }
        echo '<option value="0" seleordersd="seleordersd">Select Product</option>'.$option;
        //echo $option;
        die();

}
add_action('wp_ajax_nopriv_rx_get_cat_child', 'rx_get_cat_child');
add_action('wp_ajax_rx_get_cat_child', 'rx_get_cat_child');

function rx_order_submit(){
	global $wpdb;
		
		$variableData = $_REQUEST['data'];
		$userData = array();
		$productArray = array();
		foreach ($variableData as $key => $value) {
			if (strpos($value['name'], 'product_') !== false) {	
				if(!empty($value['value'])){			
    				$productArray[$value['name']][] =  $value['value'];
    			}else {
    				$productArray[$value['name']][] =  " ";
    			}				    		
			}
			else{
				$userData[$value['name']] =  $value['value'] ;
			}
		}

		$customer_name			= $userData['customer_name'];
		$customer_email			= $userData['customer_email'];
		$mobile_number			= $userData['mobile_number'];
		$product_data			= serialize($productArray);

		$nowdate = date('Y-m-d H:i:s',time());
		$dataInsert =	 array(
				"customer_name" => $customer_name,
				"customer_email"=> $customer_email,
				"mobile_number" => $mobile_number,
				"product_data" 	=> $product_data,				
				"date" 			=> $nowdate,		
				);
		
		$order = $wpdb->insert(
			$wpdb->prefix."orders",
			$dataInsert,
			array( 
				'%s', 
				'%s', 
				'%s',
				'%s',
				'%s'
			) 
		);
		$orderID = $wpdb->insert_id;
		
		if($order){			
			$msg = "Your Order added successfully";
			$status = true;
		}
		else{
			$status = false; 
			$msg = "Something went Wrong.";
		}

			$mailData = array();
			foreach ($productArray as $key => $value) {
				foreach ($value as $k => $product) {
					
					$mailData[$k][$key] = $product;				
				}				
			}
			
		
		if($status){
		
		############################# send email start ##########################
			//$admin_email = 'urmil.patel@radixweb.com';
			$admin_email = get_option( 'admin_email' ); 
			$multiple_recipients = array($customer_email,$admin_email);


			$subject = 'Order ID - "'.$orderID.'" From Premier Industries Ltd';
			
			$headers = "";
			//$headers .= "Reply-To: ". strip_tags($admin_email) . "\r\n";
			//$headers .= "MIME-Version: 1.0\r\n";
			$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
			
			$message = "";
			$message .= "<html>";
			$message .= "<head>";
			$message .= "<style>
    			body { margin:0px; padding: 0px; background: #ccc; font-family: Arial, Helvetica, sans-serif; font-size: 16px; line-height: 22px; color: #000000; }
    			p, h1, h2, h3, h4, h5, h6, ul , li { margin: 0px; padding: 0px;}
			    img { border: 0px; max-width:100%;height:auto;}
			    tr{border: 0; border-collapse: collapse; border-spacing: 0;margin:0px auto;}
			    table {margin-top: 0; margin-bottom:0; padding: 0px; font-family: Arial, Helvetica, sans-serif;}td{font-size:16px; font-family:arial;color: #000000;}
			</style>";
			$message .= "</head>";
			$message .= "<body>";	

    		$message .= "<table width='600' border='0' align='center' cellpadding='0' cellspacing='0' bgcolor='#ffffff'>";
		    $message .= "<tr>
		            		<td height='30'></td>
		            		<td align='center'></td>
		            		<td></td>
		        		</tr>
        				<tr>
            				<td width='30'></td>
            				<td align='center'>";
            				
            $message .= "<table width='100%'>
                		<tr>
	                    	<td align='left' valign='middle'><img src='". get_template_directory_uri() ."/assets/images/logo.png' alt='logo'
	                        width='160' height='108' /></td>
	                    	<td></td>
	                    	<td></td>
	                    	<td align='right' valign='top' height='30'><p style='font-size: 20px;line-height:20px;color:#ffffff;background-color: #eb1923; padding: 10px; text-align: center; font-weight: bold; text-transform: uppercase;'>Order Id : ".$orderID."</p></td>
                		</tr>
            			</table>";
            $message .= "</td>";
            $message .= "<td width='30'></td>
				        </tr>
				        <tr>
				            <td height='30'></td>
				            <td align='center'></td>
				            <td></td>
				        </tr>
				        <tr>
				            <td></td>
				            <td><p style='font-family: Arial, Helvetica, sans-serif; font-size:18px;line-height:24px;color:#000;'><strong>Customer Name: </strong>".$customer_name. "</p></td>
				            <td></td>
				        </tr>
				        <tr>
				            <td height='10'></td>
				            <td align='center'></td>
				            <td></td>
				        </tr>
				        <tr>
				            <td></td>
				            <td><p style='font-size:18px;line-height:26px;color:#000;'><strong>Customer Email: </strong>".$customer_email."</p></td>
				            <td></td>
				        </tr>
				        <tr>
				            <td height='10'></td>
				            <td align='center'></td>
				            <td></td>
				        </tr>        
				        <tr>
				            <td></td>
				            <td><p style='font-size:18px;line-height:24px;color:#000;'><strong>Customer Mobile: </strong>".$mobile_number."</p></td>
				            <td></td>
				        </tr>
				        <tr>
				            <td height='20'></td>
				            <td align='center'></td>
				            <td></td>
				        </tr>  
				        <tr>
				            <td></td>
				            <td>";

                $message .= "<table width='100%' border='1' cellspacing='1' cellpadding='1'>
                    <tr>
                        <th colspan='5' align='center' height='40'>Product Details</th>
                    </tr>
                    <tr>
                        <td align='center' valign='middle' width='20%' height='60'>
                            <p style='font-size:18px;line-height:24px;color:#000;font-weight:bold;'>Sr. No</p>
                        </td>
                        <td align='center' valign='middle' width='20%'>
                            <p style='font-size:18px;line-height:24px;color:#000;font-weight:bold;'> Product Group </p>
                        </td>
                        <td align='center' valign='middle' width='20%'>
                            <p style='font-size:18px;line-height:24px;color:#000;font-weight:bold;'> Product Name </p>
                        </td>
                        <td align='center' valign='middle' width='20%'>
                            <p style='font-size:18px;line-height:24px;color:#000;font-weight:bold;'> Product Description </p>
                        </td>
                        <td align='center' valign='middle' width='20%'>
                            <p style='font-size:18px;line-height:24px;color:#000;font-weight:bold;'> Product Quantity </p>
                        </td>
                    </tr>";

                    $k=1;
					foreach ($mailData as $index => $tr) {
							
						$message .= "<tr>";
						$message .= "<td height='15' align='center'><p style='font-size:18px;line-height:24px;color:#000;'>".$k."</p></td>";
						$message .= "<td height='15' align='center'><p style='font-size:18px;line-height:24px;color:#000;'>".$tr['product_group']."</p></td>";
						$message .= "<td height='15' align='center'><p style='font-size:18px;line-height:24px;color:#000;'>".$tr['product_name']."</p></td>";
						$message .= "<td height='15' align='center'><p style='font-size:18px;line-height:24px;color:#000;'>".$tr['product_description']."</p></td>";
						$message .= "<td height='15' align='center'><p style='font-size:18px;line-height:24px;color:#000;'>".$tr['product_qty']."</p></td>";
						$message .= "</tr>";

						$k++;
					}
                
                
                $message .= "</table>";
            $message .= "</td>
            				<td></td>            
        				</tr>
        				<tr>
            				<td height='30'></td>
            				<td align='center'></td>
            				<td></td>
        				</tr>
    				</table>";
 			$message .= "</body>";
			$message .= "</html>";
			
			$mailsent = wp_mail($multiple_recipients,$subject,$message,$headers);
			
			
		}
			############################# send email end ############################
		$response_array = array( 'status' => $status, 'message' => $msg);
		echo json_encode($response_array);
			
		die();

}
add_action('wp_ajax_nopriv_rx_order_submit', 'rx_order_submit');
add_action('wp_ajax_rx_order_submit', 'rx_order_submit');


// Add Shortcode
function up_custom_shortcode($atts) { 
	ob_start();
	?>
	
	<div id="book-order-form">
		
		<form role="form" id="book_order_form" class="row premier-order-form" method="POST" action="">
			<div class="frm-field col-md-4 form-group">
				<label for="customer_name">Customer Name <span class="required">*</span></label>
				<input type="text" name="customer_name" id="customer_name" class="isrequired form-control">
			</div>
			<div class="frm-field col-md-4 form-group">
				<label for="customer_email">Customer Email <span class="required">*</span></label>
				<input type="email" name="customer_email" id="customer_email" class="isrequired form-control">
			</div>
			<div class="frm-field col-md-4 form-group">
				<label for="mobile_number">Mobile Number <span class="required">*</span></label>
				<input type="text" name="mobile_number" id="mobile_number" class="isrequired form-control" maxlength="10"></textarea>
			</div>
			<div class="dublicate_field_wrapper col-md-12" id="dublicate_section_warp_main">
				<div class="input_fields_wrap row" id="product_group_1" data-attr="1">
					
					<div class="frm-field col-md-6 form-group ">
						<label for="product_group">Product Group <span class="required">*</span></label>
						<div class="custom_select_box">
						<?php
					        $orders_category_terms = get_terms('order_cat', array('hide_empty' => false, 'parent' => 0 ));
					        if ( !empty($orders_category_terms) ) :
				                	echo '<select class="form-control form-control-lg font-light get_parent isrequired" name="product_group" id="product_group" >
			                                    <option value="" seleordersd="seleordersd">Select Products</option>';
			                                   foreach ( $orders_category_terms as $orders_category_term ) : ?>
			                                   			<option class="get_cat_parent_value" data-cat-parent-slug="<?php echo $orders_category_term->slug; ?>"  data-cat-parent-id="<?php echo $orders_category_term->term_id; ?>" value="<?php echo $orders_category_term->name; ?>"><?php echo $orders_category_term->name; ?></option>
			                             <?php endforeach;
			                        echo '</select>';

					        endif;       
					    ?>
						</div>
					</div>    
				    <div class="frm-field col-md-6 form-group">
						<label for="product_name">Product Name</label>
						<div class="custom_select_box">
							<select id="child" class="form-control form-control-lg font-light get_cat_child child" name="product_name" disabled="disabled"></select>
							</div>
					</div>
					<div class="frm-field col-md-6 form-group">
						<label for="product_description">Product Description</label>
						<div class="custom_select_box">
							<select id="pro_child_desc" class="form-control form-control-lg font-light pro_child_desc" name="product_description" disabled="disabled"></select>
							</div>
					</div>
				    <div class="frm-field col-md-6 form-group">
						<label for="product_qty">Order Qty <span class="required">*</span></label>
						<input type="text" name="product_qty" id="product_qty" class="isrequired form-control product_qty"></textarea>
					</div>
				</div>
			</div>
				<div class="col-md-12 text-right mt-2 mb-2"><a id="add_field_button" class="add_more_fields"><span>+</span> Add More Products</a></div>
			<div class="frm-field col-md-12 mt-2">
				<input class="submit_book_btn  btn text-red regular-font diagonal-swipe submit" type="button" value="Order">
				
			</div>
			<div class=" col-md-12 mt-3  "><div id="notic_book_order" class="alert"></div></div>
		</form>
	</div>


	<?php

	$html = ob_get_contents();
	ob_end_clean();
	return $html;
}
add_shortcode( 'order_frm', 'up_custom_shortcode' );
//[order_frm]



add_filter( 'wp_mail_from', 'custom_wp_mail_from' );
function custom_wp_mail_from( $original_email_address ) {
	//Make sure the email is from the same domain 
	//as your website to avoid being marked as spam.
	return 'wordpress@premierindltd.radixdev13.com';
}
