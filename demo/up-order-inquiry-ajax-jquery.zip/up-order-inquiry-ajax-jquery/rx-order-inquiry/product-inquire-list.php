<div class="wrap">
    <h2>Inquire List</h2>
	 <table class="wp-list-table widefat fixed display" id="inquireList">
		<thead>
			<tr>
				<th></th>
				<th>ID</th>
				<th>Name</th>
				<th>Email</th>
				<th>Mobile</th>				
				<th>Date</th>
				<th>Action</th>
            </tr>
		</thead>
		<tbody>
<?php

	global $wpdb;	
	$tablename = $wpdb->prefix.'orders';
	$result = $wpdb->get_results("select * from ".$tablename." ORDER BY id DESC");
	
	
		if ($result){

			foreach($result  as $results ){
								
				$id        				= $results->id;
				$customer_name  		= $results->customer_name;
				$customer_email  		= $results->customer_email;
				$mobile_number  		= $results->mobile_number;
				$productArray  			= $results->product_data;
				$productsData 			= unserialize($productArray);
				$date 					= $results->date;

			?>
			
			<tr class="orderID_<?php echo $results->id; ?>">
				<td>
				<div class="accordion_head" data-attr="showID_<?php echo $results->id; ?>">View Products<span class="plusminus">+</span></div>
				<div class="accordion_body" style="display: none;">
					    
					    	<table width='100%' class="wp-list-table widefat fixed display" >
					    	<thead>
								<tr>
								<th width='25%'>Product Group</th>
								<th width='25%'>Product Name</th>
								<th width='25%'>Product Desscription</th>
								<th width='25%'>Product Quantity</th>
								</tr>
							</thead>	
					    <?php 
					    	$i=1;
							$proData = array();
							foreach ($productsData as $key => $trvalue) {
							    foreach ($trvalue as $k => $product) {
									$proData[$k][$key] = $product;				
								}

							$i++;	
							}

							$k=1;
							foreach ($proData as $index => $tr) {

								echo "<tr>";
								echo "<td height='15'>".$tr['product_group']."</td>";
								echo "<td height='15'>".$tr['product_name']."</td>";
								echo "<td height='15'>".$tr['product_description']."</td>";
								echo "<td height='15'>".$tr['product_qty']."</td>";
								echo "</tr>";
							}
						
						?>
							</table>
					    
					  </div>	
				</td>

				<td><a href=""><?php echo $id; ?></a></td>
				<td><?php echo $customer_name; ?></td>
                <td><?php echo $customer_email; ?></td>
				<td><?php echo $mobile_number;?></td>
				<?php /*<td><?php echo $mydata['product_group'][0];?></td>
				<td><?php echo $mydata['product_name'][0];?></td>
				<td><?php echo $mydata['product_description'][0];?></td>
				<td><?php echo $mydata['product_qty'][0];?></td>  */ ?>
				<td><?php echo $date;?></td>
				<td><a href="#" id="<?php echo $results->id; ?>" class="del_inquire">Delete</a></td>
			</tr>
	<?php }
		} else { ?>
				<tr align="center">
					<td colspan="6">No Record Found!</td>
				<tr>
		<?php } ?>
		</tbody>
		</table>
	
	</div>


<script type="text/javascript">
jQuery(document).ready(function() {
	jQuery(".del_inquire").click(function() {
		var del_id = jQuery(this).attr("id");
			
		var user_confirm = confirm("Are you sure to delete this record?");
		if (user_confirm == true) {
				jQuery.ajax({
				url: ajaxurl,
				data: {
					'action':'del_inquire_record',
					'del_id' : del_id
				},
				 success:function(data) {
					location.reload(true);					
			},
		error: function(errorThrown){
			console.log(errorThrown);
			alert("Error in delete");
		}
		});
		} 
	});

	jQuery(".accordion_head").click(function() {
	    
	    var curBody = jQuery(this).parents("tr").find(".accordion_body").html(); 
	    var curBodyClass = jQuery(this).attr('data-attr');
	    
	    if(jQuery("."+curBodyClass).length == 0){	    	
	    	jQuery(this).parents("tr").after('<tr class="'+curBodyClass+'"><td colspan="7">'+curBody+'</td></tr> ');
	    	jQuery("."+curBodyClass).slideDown(300);
	    	jQuery("."+curBodyClass).addClass('open');
	    	jQuery(this).children(".plusminus").text('-');
		}
		else{
			if(jQuery("."+curBodyClass+".open").is(":visible")){
				jQuery("."+curBodyClass).slideUp(300);
				jQuery(this).children(".plusminus").text('+');
			}
			else {
				jQuery("."+curBodyClass).slideDown(300);
				jQuery(this).children(".plusminus").text('-');
			}
		}
		
	  });

});
</script>		
<style type="text/css">
.accordion_head {
  background-color: skyblue;
  color: white;
  cursor: pointer;
  font-family: arial;
  font-size: 14px;
  margin: 0 0 1px 0;
  padding: 7px 11px;
  font-weight: bold;
}

.accordion_body {
  background: lightgray;
}

.accordion_body p {
  padding: 10px 5px;
  margin: 0px;
}

.plusminus {
  float: right;
}
td.dataTables_empty {
    display: none;
}
</style>